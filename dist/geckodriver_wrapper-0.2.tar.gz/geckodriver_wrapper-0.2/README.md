This is a packaged version of geckodriver for offline use.
Driver Release: https://github.com/mozilla/geckodriver/releases/tag/v0.35.0 geckodriver-v0.35.0-win32.zip
Driver License: https://github.com/mozilla/geckodriver?tab=MPL-2.0-1-ov-file#readme MPL-2.0 license